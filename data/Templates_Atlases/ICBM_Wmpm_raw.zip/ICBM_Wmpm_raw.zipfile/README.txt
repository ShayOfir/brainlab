
In October 2009, we identified a minor problem with the MNC and NIFTI volumes of all ICBM atlases distributed at http://www.loni.ucla.edu/Atlases/. The problem with these two file formats was that the atlas' origins (AC centers) were incorrectly set to (0,0,0). We corrected these to (-90,-126,-72) using the scripts available in this LONI disk partition (/ifs/ccb/data/ICBM/Atlases/ICBM_AtlasFix_Oct2009_MNC_NIFTI_HDR/).

Affected atlases were the MNC and NiFTI volumes in the following atlases:
http://www.loni.ucla.edu/Atlases/Atlas_Detail.jsp?atlas_id=15
http://www.loni.ucla.edu/Atlases/Atlas_Detail.jsp?atlas_id=5
http://www.loni.ucla.edu/Atlases/Atlas_Detail.jsp?atlas_id=13
http://www.loni.ucla.edu/Atlases/Atlas_Detail.jsp?atlas_id=7
http://www.loni.ucla.edu/Atlases/Atlas_Detail.jsp?atlas_id=6

